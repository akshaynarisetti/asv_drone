#!/usr/bin/env python

'''
This python file runs a ROS-node of name attitude_control which controls the roll pitch and yaw angles of the eDrone.
This node publishes and subsribes the following topics:
        PUBLICATIONS            SUBSCRIPTIONS
        /roll_error             /pid_tuning_altitude
        /pitch_error            /pid_tuning_pitch
        /yaw_error              /pid_tuning_roll
        /edrone/pwm             /edrone/imu/data
                                /edrone/drone_command


'''

# Importing the required libraries

from asv_drone.msg import *
from pid_tune.msg import PidTune
from sensor_msgs.msg import Imu
from std_msgs.msg import Float32
import rospy
import time
from tf.transformations import euler_from_quaternion, quaternion_from_euler


class Edrone():
    """docstring for Edrone"""
    def __init__(self):
        rospy.init_node('attitude_controller')  # initializing ros node with name attitude_controller

        # This corresponds to your current orientation of eDrone in quaternion format. This value must be updated each time in your imu callback
        # [x,y,z,w]
        self.drone_orientation_quaternion = [0.0, 0.0, 0.0, 0.0]

        # This corresponds to your current orientation of eDrone converted in euler angles form.
        # [r,p,y]
        self.drone_orientation_euler = [0.0, 0.0, 0.0]

        # This is the setpoint that will be received from the drone_command in the range from 1000 to 2000
        # [r_setpoint, p_setpoint, y_setpoint]
        self.setpoint_cmd = [0.0, 0.0, 0.0,0.0]

        # The setpoint of orientation in euler angles at which you want to stabilize the drone
        # [r_setpoint, p_psetpoint, y_setpoint]
        self.setpoint_euler = [0.0, 0.0, 0.0]
        #For storing the errors of individual [roll,pitch,yaw]
        self.error = [0,0,0]
        # Declaring pwm_cmd of message type prop_speed and initializing values
       

        self.pwm_cmd = prop_speed()
        self.pwm_cmd.prop1 = 0.0
        self.pwm_cmd.prop2 = 0.0
        self.pwm_cmd.prop3 = 0.0
        self.pwm_cmd.prop4 = 0.0

        # Final setting of Kp, Kd and ki for [roll, pitch, yaw]
    
        self.Kp = [0, 0, 0] #kp values of [roll,pitch,yaw]
        self.Ki = [0, 0, 0] #ki values of [roll,pitch,yaw]
        self.Kd = [0, 0, 0] #ki values of [roll,pitch,yaw]
        # -----------------------Add other required variables for pid here ----------------------------------------------
        
      
       
        
        self.sample_time = 17 # sample time in seconds

        # Publishing /edrone/pwm, /roll_error, /pitch_error, /yaw_error ,/zero_error
        self.pwm_pub = rospy.Publisher('/edrone/pwm', prop_speed, queue_size=1)
        self.roll_pub = rospy.Publisher('/roll_error', Float32, queue_size=1)
        self.pitch_pub = rospy.Publisher('/pitch_error', Float32, queue_size=1)
        self.yaw_pub = rospy.Publisher('/yaw_error', Float32, queue_size=1)
        self.set_pub = rospy.Publisher('/zero_error', Float32, queue_size=1)
        
        

        # Subscribing to /drone_command, imu/data, /pid_tuning_roll, /pid_tuning_pitch, /pid_tuning_yaw
        rospy.Subscriber('/drone_command', edrone_cmd, self.drone_command_callback)
        rospy.Subscriber('/edrone/imu/data', Imu, self.imu_callback)
        rospy.Subscriber('/pid_tuning_roll', PidTune, self.roll_set_pid)
        rospy.Subscriber('/pid_tuning_pitch', PidTune, self.pitch_set_pid)
        rospy.Subscriber('/pid_tuning_yaw', PidTune, self.yaw_set_pid)
    # Imu callback function
    # The function gets executed each time when imu publishes /edrone/imu/data
    def imu_callback(self, msg):

        self.drone_orientation_quaternion[0] = msg.orientation.x
        self.drone_orientation_quaternion[1] = msg.orientation.y
        self.drone_orientation_quaternion[2] = msg.orientation.z
        self.drone_orientation_quaternion[3] = msg.orientation.w
        # --------------------Set the remaining co-ordinates of the drone from msg----------------------------------------------

    def drone_command_callback(self, msg):
        self.setpoint_cmd[0] = msg.rcRoll
        self.setpoint_cmd[1] = 
        self.setpoint_cmd[2] = 
        self.setpoint_cmd[3] = 
        # ---------------------------------------------------------------------------------------------------------------
   

    # Callback function for /pid_tuning_roll


    # This function gets executed each time when /tune_pid publishes /pid_tuning_roll
    def roll_set_pid(self, roll):
        self.Kp[0] = roll.Kp * 0.06 
        self.Ki[0] = roll.Ki * 0.008
        self.Kd[0] = roll.Kd * 0.3

    # This function gets executed each time when /tune_pid publishes /pid_tuning_pitch
    def pitch_set_pid(self, pitch):
        self.Kp[1] = pitch.Kp * 5
        self.Ki[1] = pitch.Ki * 0.008
        self.Kd[1] = pitch.Kd * 0.3

    # This function gets executed each time when /tune_pid publishes /pid_tuning_yaw   
    def yaw_set_pid(self, yaw):
        self.pid[0] = yaw.Kp * 6  
        self.pid[1] = yaw.Ki * 0.001
        self.pid[2] = yaw.Kd * 2000

    

    #----------------------------------------------------------------------------

    def pid(self):
        
        # Steps:
        #   1. Convert the quaternion format of orientation to euler angles
        #   2. Convert the setpoint that is in the range of 1000 to 2000 into angles with the limit from -10 degree to 10 degree in euler angles
        #   3. Compute error in each axis. eg: error[0] = self.setpoint_euler[0] - self.drone_orientation_euler[0], where error[0] corresponds to error in roll...
        #   4. Compute the error (for proportional), change in error (for derivative) and sum of errors (for integral) in each axis. Refer "Understanding PID.pdf" to understand PID equation.
        #   5. Calculate the pid output required for each axis. For eg: calcuate self.out_roll, self.out_pitch, etc.
        #   6. Use this computed output value in the equations to compute the pwm for each propeller. LOOK OUT FOR SIGN (+ or -). EXPERIMENT AND FIND THE CORRECT SIGN
        #   7. Don't run the pid continously. Run the pid only at the a sample time. self.sampletime defined above is for this purpose. THIS IS VERY IMPORTANT.
        #   8. Limit the output value and the final command value between the maximum(0) and minimum(1024)range before publishing. For eg : if self.pwm_cmd.prop1 > self.max_values[1]:
        #                                                                                                                                      self.pwm_cmd.prop1 = self.max_values[1]
        #   8. Update previous errors.eg: self.prev_error[1] = error[1] where index 1 corresponds to that of pitch (eg)
        #   9. Add error_sum to use for integral component

        # Converting quaternion to euler angles
        (self.drone_orientation_euler[0], self.drone_orientation_euler[1], self.drone_orientation_euler[2]) = euler_from_quaternion([self.drone_orientation_quaternion[0], self.drone_orientation_quaternion[1], self.drone_orientation_quaternion[2], self.drone_orientation_quaternion[3]])
       
        # Convertng the range from 1000 to 2000 in the range of -10 degree to 10 degree for roll axis
        self.setpoint_euler[1] = self.setpoint_cmd[0] * 0.02 - 30
        self.setpoint_euler[0] = self.setpoint_cmd[1] * 0.02 - 30
        self.setpoint_euler[2] = self.setpoint_cmd[2] * 0.02 - 30
      
       
        
        self.setpoint_euler[0] = self.setpoint_euler[0]/57.296 #converting setpoint from degrees to radians as imu data is in radians
        self.setpoint_euler[1] = self.setpoint_euler[1]/57.296 #converting setpoint from degrees to radians as imu data is in radians
        self.setpoint_euler[2] = self.setpoint_euler[2]/57.296 #converting setpoint from degrees to radians as imu data is in radians
       
       
        
  
        
if __name__ == '__main__':

    e_drone = Edrone() #Making an object e_drone
    r = rospy.Rate(e_drone.sample_time) #specifing the rate at which the pid loop should execute
    while not rospy.is_shutdown(): #Run until the shutdown message is recieved

        e_drone.pid() #calling pid function using object e_drone
     
        e_drone.roll_pub.publish(e_drone.error[0]) #publishing roll error for pid tuning using plot juggler
        e_drone.pitch_pub.publish(e_drone.error[1])  #publishing pitch error for pid tuning using plot juggler
        e_drone.yaw_pub.publish(e_drone.error[2])  #publishing yaw error for pid tuning using plot juggler
        e_drone.set_pub.publish(e_drone.min_values[2])  #publishing zero error for pid tuning using plot juggler
        r.sleep() #sleep for certain time speciefied in the rospy.Rate() function i.e the sampling time 
